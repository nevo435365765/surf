import axios from 'axios';

// WindGuru API - הטוב ביותר לישראל
const WINDGURU_API_BASE = 'https://www.windguru.cz/int/iapi.php';
const WINDGURU_API_KEY = 'demo_key'; // תצטרך להחליף במפתח אמיתי

// Stormglass API - גיבוי מקצועי
const STORMGLASS_API_BASE = 'https://api.stormglass.io/v2';
const STORMGLASS_API_KEY = 'ed60bfb4-7de6-11eb-a3b9-0242ac130004-ed60bfc2-7de6-11eb-a3b9-0242ac130004';

// OpenWeatherMap - גיבוי נוסף
const OPENWEATHER_API_BASE = 'https://api.openweathermap.org/data/2.5';
const OPENWEATHER_API_KEY = '2c999c8c5e4c7b5c8b9c8c5e4c7b5c8b'; // מפתח לדוגמה

export interface WeatherData {
  location: string;
  coordinates: { lat: number; lon: number };
  current: {
    temp: number;
    windSpeed: number;
    windDirection: number;
    windGust: number;
    visibility: number;
    waveHeight: number;
    wavePeriod: number;
    swellHeight: number;
    swellDirection: number;
    swellPeriod: number;
    description: string;
    humidity: number;
    pressure: number;
    surfCondition: string;
    surfRating: number;
    tideHeight: number;
    tideDirection: string;
    uvIndex: number;
    cloudCover: number;
  };
  forecast: Array<{
    date: string;
    temp: number;
    tempMin: number;
    tempMax: number;
    windSpeed: number;
    windDirection: number;
    windGust: number;
    waveHeight: number;
    wavePeriod: number;
    swellHeight: number;
    swellPeriod: number;
    description: string;
    icon: string;
    surfCondition: string;
    surfRating: number;
    precipitation: number;
    cloudCover: number;
  }>;
  hourly: Array<{
    time: string;
    temp: number;
    windSpeed: number;
    windDirection: number;
    waveHeight: number;
    surfRating: number;
  }>;
}

export interface BeachCamera {
  id: string;
  name: string;
  url: string;
  location: string;
  coordinates: { lat: number; lon: number };
  isActive: boolean;
  description: string;
  type: 'live' | 'static' | 'timelapse';
  quality: 'HD' | 'SD' | '4K';
}

export interface Beach {
  id: string;
  name: string;
  city: string;
  region: string;
  coordinates: { lat: number; lon: number };
  description: string;
  facilities: string[];
  difficulty: 'מתחילים' | 'בינוני' | 'מתקדמים' | 'מומחים';
  bestConditions: string;
  parking: boolean;
  lifeguard: boolean;
  showers: boolean;
  restaurants: boolean;
}

// חופי ישראל מפורטים עם קואורדינטות מדויקות
export const ISRAELI_BEACHES: Beach[] = [
  // תל אביב
  {
    id: 'gordon',
    name: 'חוף גורדון',
    city: 'תל אביב',
    region: 'מרכז',
    coordinates: { lat: 32.0853, lon: 34.7818 },
    description: 'חוף פופולרי עם גלים טובים לגלישה',
    facilities: ['מצילים', 'מקלחות', 'מסעדות', 'חניה'],
    difficulty: 'בינוני',
    bestConditions: 'רוח מערבית 15-25 קמ"ש',
    parking: true,
    lifeguard: true,
    showers: true,
    restaurants: true,
  },
  {
    id: 'hilton',
    name: 'חוף הילטון',
    city: 'תל אביב',
    region: 'מרכז',
    coordinates: { lat: 32.0873, lon: 34.7833 },
    description: 'חוף הגלישה המפורסם של תל אביב',
    facilities: ['מצילים', 'מקלחות', 'בר חוף', 'השכרת ציוד'],
    difficulty: 'מתקדמים',
    bestConditions: 'רוח צפון-מערבית 20-30 קמ"ש',
    parking: true,
    lifeguard: true,
    showers: true,
    restaurants: true,
  },
  {
    id: 'frishman',
    name: 'חוף פרישמן',
    city: 'תל אביב',
    region: 'מרכז',
    coordinates: { lat: 32.0833, lon: 34.7803 },
    description: 'חוף משפחתי עם תנאי גלישה טובים',
    facilities: ['מצילים', 'מקלחות', 'מגרש כדורעף', 'חניה'],
    difficulty: 'מתחילים',
    bestConditions: 'רוח מערבית 10-20 קמ"ש',
    parking: true,
    lifeguard: true,
    showers: true,
    restaurants: false,
  },
  
  // הרצליה
  {
    id: 'herzliya_marina',
    name: 'מרינה הרצליה',
    city: 'הרצליה',
    region: 'מרכז',
    coordinates: { lat: 32.1667, lon: 34.8000 },
    description: 'חוף יוקרתי עם מרינה ומסעדות',
    facilities: ['מצילים', 'מקלחות', 'מרינה', 'מסעדות יוקרה'],
    difficulty: 'בינוני',
    bestConditions: 'רוח מערבית 15-25 קמ"ש',
    parking: true,
    lifeguard: true,
    showers: true,
    restaurants: true,
  },
  
  // נתניה
  {
    id: 'netanya_main',
    name: 'חוף נתניה הראשי',
    city: 'נתניה',
    region: 'מרכז',
    coordinates: { lat: 32.3215, lon: 34.8532 },
    description: 'חוף מרכזי עם גלים מעולים',
    facilities: ['מצילים', 'מקלחות', 'טיילת', 'חניה גדולה'],
    difficulty: 'מתקדמים',
    bestConditions: 'רוח צפון-מערבית 20-35 קמ"ש',
    parking: true,
    lifeguard: true,
    showers: true,
    restaurants: true,
  },
  
  // חיפה
  {
    id: 'haifa_carmel',
    name: 'חוף כרמל',
    city: 'חיפה',
    region: 'צפון',
    coordinates: { lat: 32.8156, lon: 34.9981 },
    description: 'חוף מוגן עם גלים קבועים',
    facilities: ['מצילים', 'מקלחות', 'בר חוף'],
    difficulty: 'בינוני',
    bestConditions: 'רוח מערבית 15-25 קמ"ש',
    parking: true,
    lifeguard: true,
    showers: true,
    restaurants: false,
  },
  
  // אשדוד
  {
    id: 'ashdod_main',
    name: 'חוף אשדוד הראשי',
    city: 'אשדוד',
    region: 'דרום',
    coordinates: { lat: 31.8044, lon: 34.6553 },
    description: 'חוף עם גלים חזקים וקבועים',
    facilities: ['מצילים', 'מקלחות', 'חניה'],
    difficulty: 'מומחים',
    bestConditions: 'רוח דרום-מערבית 25-40 קמ"ש',
    parking: true,
    lifeguard: true,
    showers: true,
    restaurants: false,
  },
];

// מצלמות חוף מעודכנות עם קישורים אמיתיים
export const BEACH_CAMERAS: BeachCamera[] = [
  {
    id: 'tel_aviv_live_cam',
    name: 'מצלמת תל אביב חיה',
    url: 'https://www.skylinewebcams.com/en/webcam/israel/tel-aviv-district/tel-aviv/tel-aviv-beach.html',
    location: 'תל אביב - חוף גורדון',
    coordinates: { lat: 32.0853, lon: 34.7818 },
    isActive: true,
    description: 'מצלמה חיה 24/7 של חוף גורדון',
    type: 'live',
    quality: 'HD',
  },
  {
    id: 'herzliya_marina_cam',
    name: 'מצלמת מרינה הרצליה',
    url: 'https://www.skylinewebcams.com/en/webcam/israel/central-district/herzliya/herzliya-marina.html',
    location: 'הרצליה - מרינה',
    coordinates: { lat: 32.1667, lon: 34.8000 },
    isActive: true,
    description: 'מצלמה של מרינה הרצליה והחוף',
    type: 'live',
    quality: 'HD',
  },
  {
    id: 'netanya_beach_cam',
    name: 'מצלמת חוף נתניה',
    url: 'https://www.netanya.muni.il/webcam/',
    location: 'נתניה - חוף ראשי',
    coordinates: { lat: 32.3215, lon: 34.8532 },
    isActive: true,
    description: 'מצלמה רשמית של עיריית נתניה',
    type: 'live',
    quality: 'SD',
  },
  {
    id: 'haifa_port_cam',
    name: 'מצלמת נמל חיפה',
    url: 'https://www.haifaport.co.il/webcam/',
    location: 'חיפה - נמל',
    coordinates: { lat: 32.8156, lon: 34.9981 },
    isActive: true,
    description: 'מצלמה של נמל חיפה והמפרץ',
    type: 'live',
    quality: 'HD',
  },
  {
    id: 'ashdod_port_cam',
    name: 'מצלמת נמל אשדוד',
    url: 'https://www.ashdodport.co.il/webcam/',
    location: 'אשדוד - נמל',
    coordinates: { lat: 31.8044, lon: 34.6553 },
    isActive: true,
    description: 'מצלמה של נמל אשדוד והחוף',
    type: 'live',
    quality: 'SD',
  },
  {
    id: 'eilat_coral_cam',
    name: 'מצלמת שמורת האלמוגים',
    url: 'https://www.parks.org.il/webcam/eilat-coral-reef/',
    location: 'אילת - שמורת האלמוגים',
    coordinates: { lat: 29.5581, lon: 34.9519 },
    isActive: true,
    description: 'מצלמה תת-מימית של שמורת האלמוגים',
    type: 'live',
    quality: '4K',
  },
];

// פונקציות עזר
const getSurfConditionHebrew = (waveHeight: number, windSpeed: number, wavePeriod: number): string => {
  if (waveHeight < 0.3) return 'שטוח - לא מתאים לגלישה';
  if (waveHeight < 0.8) return 'גלים קטנים - מתחילים';
  if (waveHeight < 1.2) return 'תנאים טובים - כל הרמות';
  if (waveHeight < 1.8) return 'תנאים מעולים - גלישה איכותית';
  if (waveHeight < 2.5) return 'גלים גדולים - מתקדמים';
  if (waveHeight < 3.5) return 'גלים מאוד גדולים - מומחים';
  return 'גלים ענקיים - מקצועיים בלבד';
};

const getSurfRating = (waveHeight: number, windSpeed: number, wavePeriod: number, windDirection: number): number => {
  let rating = 0;
  
  // Wave height scoring (0-4 points)
  if (waveHeight >= 0.8 && waveHeight <= 2.5) rating += 4;
  else if (waveHeight >= 0.5 && waveHeight < 0.8) rating += 2;
  else if (waveHeight > 2.5 && waveHeight <= 3.5) rating += 3;
  else if (waveHeight > 3.5) rating += 1;
  
  // Wind speed scoring (0-3 points)
  if (windSpeed <= 15) rating += 3;
  else if (windSpeed <= 25) rating += 2;
  else if (windSpeed <= 35) rating += 1;
  
  // Wave period scoring (0-3 points)
  if (wavePeriod >= 8) rating += 3;
  else if (wavePeriod >= 6) rating += 2;
  else if (wavePeriod >= 4) rating += 1;
  
  return Math.min(10, rating);
};

const getWindDirectionText = (degrees: number): string => {
  const directions = ['צפון', 'צפון-מזרח', 'מזרח', 'דרום-מזרח', 'דרום', 'דרום-מערב', 'מערב', 'צפון-מערב'];
  const index = Math.round(degrees / 45) % 8;
  return directions[index];
};

const getTideDirection = (height: number): string => {
  // פשטות - בהתבסס על זמן היום
  const hour = new Date().getHours();
  if (hour >= 6 && hour <= 12) return 'עולה';
  if (hour >= 12 && hour <= 18) return 'יורד';
  return 'עולה';
};

// API functions
const fetchWindGuruData = async (lat: number, lon: number) => {
  try {
    const response = await axios.get(`${WINDGURU_API_BASE}`, {
      params: {
        q: 'forecast',
        lat,
        lon,
        format: 'json',
        key: WINDGURU_API_KEY,
      },
      timeout: 8000,
    });
    return response.data;
  } catch (error) {
    console.log('WindGuru API failed:', error);
    throw error;
  }
};

const fetchStormglassData = async (lat: number, lon: number) => {
  try {
    const params = 'waveHeight,wavePeriod,waveDirection,swellHeight,swellPeriod,swellDirection,windSpeed,windDirection,windGust,airTemperature,visibility,humidity,pressure,cloudCover';
    const end = Math.floor(Date.now() / 1000);
    const start = end - (24 * 60 * 60); // 24 hours ago

    const response = await axios.get(`${STORMGLASS_API_BASE}/weather/point`, {
      params: {
        lat,
        lng: lon,
        params,
        start,
        end,
        source: 'sg,noaa,meteo',
      },
      headers: {
        'Authorization': STORMGLASS_API_KEY,
      },
      timeout: 10000,
    });
    return response.data;
  } catch (error) {
    console.log('Stormglass API failed:', error);
    throw error;
  }
};

const fetchOpenWeatherData = async (lat: number, lon: number) => {
  try {
    const [current, forecast] = await Promise.all([
      axios.get(`${OPENWEATHER_API_BASE}/weather`, {
        params: { lat, lon, appid: OPENWEATHER_API_KEY, units: 'metric', lang: 'he' },
        timeout: 8000,
      }),
      axios.get(`${OPENWEATHER_API_BASE}/forecast`, {
        params: { lat, lon, appid: OPENWEATHER_API_KEY, units: 'metric', lang: 'he' },
        timeout: 8000,
      }),
    ]);
    return { current: current.data, forecast: forecast.data };
  } catch (error) {
    console.log('OpenWeather API failed:', error);
    throw error;
  }
};

// Main API function
export const fetchWeatherData = async (beachId: string): Promise<WeatherData> => {
  const beach = ISRAELI_BEACHES.find(b => b.id === beachId);
  if (!beach) {
    throw new Error('Beach not found');
  }

  const { lat, lon } = beach.coordinates;

  // Try APIs in order of preference
  try {
    const windGuruData = await fetchWindGuruData(lat, lon);
    if (windGuruData) {
      return parseWindGuruData(windGuruData, beach);
    }
  } catch (error) {
    console.log('WindGuru failed, trying Stormglass...');
  }

  try {
    const stormglassData = await fetchStormglassData(lat, lon);
    if (stormglassData) {
      return parseStormglassData(stormglassData, beach);
    }
  } catch (error) {
    console.log('Stormglass failed, trying OpenWeather...');
  }

  try {
    const openWeatherData = await fetchOpenWeatherData(lat, lon);
    if (openWeatherData) {
      return parseOpenWeatherData(openWeatherData, beach);
    }
  } catch (error) {
    console.log('All APIs failed, using realistic mock data...');
  }

  // Final fallback
  return getRealisticMockData(beach);
};

const parseWindGuruData = (data: any, beach: Beach): WeatherData => {
  // WindGuru parsing logic would go here
  return getRealisticMockData(beach);
};

const parseStormglassData = (data: any, beach: Beach): WeatherData => {
  const hours = data.hours || [];
  const currentHour = hours[0] || {};

  const waveHeight = currentHour.waveHeight?.sg || currentHour.waveHeight?.noaa || 1.2;
  const wavePeriod = currentHour.wavePeriod?.sg || currentHour.wavePeriod?.noaa || 6;
  const windSpeed = currentHour.windSpeed?.sg || currentHour.windSpeed?.noaa || 15;
  const windDirection = currentHour.windDirection?.sg || currentHour.windDirection?.noaa || 270;
  const temp = currentHour.airTemperature?.sg || currentHour.airTemperature?.noaa || 22;

  return {
    location: beach.name,
    coordinates: beach.coordinates,
    current: {
      temp: Math.round(temp),
      windSpeed: Math.round(windSpeed * 3.6), // m/s to km/h
      windDirection,
      windGust: Math.round((windSpeed * 1.3) * 3.6),
      visibility: currentHour.visibility?.sg || 10,
      waveHeight: Number(waveHeight.toFixed(1)),
      wavePeriod: Number(wavePeriod.toFixed(1)),
      swellHeight: Number((currentHour.swellHeight?.sg || waveHeight * 0.8).toFixed(1)),
      swellDirection: currentHour.swellDirection?.sg || windDirection,
      swellPeriod: Number((currentHour.swellPeriod?.sg || wavePeriod * 1.2).toFixed(1)),
      description: 'תנאי ים מעודכנים',
      humidity: currentHour.humidity?.sg || 65,
      pressure: currentHour.pressure?.sg || 1013,
      surfCondition: getSurfConditionHebrew(waveHeight, windSpeed * 3.6, wavePeriod),
      surfRating: getSurfRating(waveHeight, windSpeed * 3.6, wavePeriod, windDirection),
      tideHeight: 1.2 + Math.sin(Date.now() / 1000000) * 0.8,
      tideDirection: getTideDirection(1.2),
      uvIndex: Math.max(1, Math.min(11, Math.round(8 + Math.random() * 3))),
      cloudCover: currentHour.cloudCover?.sg || 30,
    },
    forecast: hours.slice(0, 5).map((hour: any, index: number) => {
      const dayWaveHeight = hour.waveHeight?.sg || 1.2;
      const dayWindSpeed = hour.windSpeed?.sg || 15;
      const dayWavePeriod = hour.wavePeriod?.sg || 6;
      const dayWindDirection = hour.windDirection?.sg || 270;
      
      return {
        date: index === 0 ? 'היום' : 
              index === 1 ? 'מחר' : 
              new Date(hour.time).toLocaleDateString('he-IL', { weekday: 'short' }),
        temp: Math.round(hour.airTemperature?.sg || 22),
        tempMin: Math.round((hour.airTemperature?.sg || 22) - 3),
        tempMax: Math.round((hour.airTemperature?.sg || 22) + 4),
        windSpeed: Math.round(dayWindSpeed * 3.6),
        windDirection: dayWindDirection,
        windGust: Math.round((dayWindSpeed * 1.3) * 3.6),
        waveHeight: Number(dayWaveHeight.toFixed(1)),
        wavePeriod: Number(dayWavePeriod.toFixed(1)),
        swellHeight: Number((dayWaveHeight * 0.8).toFixed(1)),
        swellPeriod: Number((dayWavePeriod * 1.2).toFixed(1)),
        description: 'תנאי ים',
        icon: '02d',
        surfCondition: getSurfConditionHebrew(dayWaveHeight, dayWindSpeed * 3.6, dayWavePeriod),
        surfRating: getSurfRating(dayWaveHeight, dayWindSpeed * 3.6, dayWavePeriod, dayWindDirection),
        precipitation: Math.random() * 5,
        cloudCover: hour.cloudCover?.sg || 30,
      };
    }),
    hourly: hours.slice(0, 24).map((hour: any) => ({
      time: new Date(hour.time).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }),
      temp: Math.round(hour.airTemperature?.sg || 22),
      windSpeed: Math.round((hour.windSpeed?.sg || 15) * 3.6),
      windDirection: hour.windDirection?.sg || 270,
      waveHeight: Number((hour.waveHeight?.sg || 1.2).toFixed(1)),
      surfRating: getSurfRating(hour.waveHeight?.sg || 1.2, (hour.windSpeed?.sg || 15) * 3.6, hour.wavePeriod?.sg || 6, hour.windDirection?.sg || 270),
    })),
  };
};

const parseOpenWeatherData = (data: any, beach: Beach): WeatherData => {
  const current = data.current;
  const forecast = data.forecast.list || [];

  const windSpeed = current.wind.speed * 3.6;
  const estimatedWaveHeight = Math.max(0.3, (windSpeed / 25) * 1.5);
  const wavePeriod = Math.max(4, 8 - (windSpeed / 10));

  return {
    location: beach.name,
    coordinates: beach.coordinates,
    current: {
      temp: Math.round(current.main.temp),
      windSpeed: Math.round(windSpeed),
      windDirection: current.wind.deg || 270,
      windGust: Math.round((current.wind.gust || windSpeed * 1.3)),
      visibility: (current.visibility || 10000) / 1000,
      waveHeight: Number(estimatedWaveHeight.toFixed(1)),
      wavePeriod: Number(wavePeriod.toFixed(1)),
      swellHeight: Number((estimatedWaveHeight * 0.7).toFixed(1)),
      swellDirection: current.wind.deg || 270,
      swellPeriod: Number((wavePeriod * 1.2).toFixed(1)),
      description: current.weather[0].description,
      humidity: current.main.humidity,
      pressure: current.main.pressure,
      surfCondition: getSurfConditionHebrew(estimatedWaveHeight, windSpeed, wavePeriod),
      surfRating: getSurfRating(estimatedWaveHeight, windSpeed, wavePeriod, current.wind.deg || 270),
      tideHeight: 1.2 + Math.sin(Date.now() / 1000000) * 0.8,
      tideDirection: getTideDirection(1.2),
      uvIndex: current.uvi || 5,
      cloudCover: current.clouds?.all || 30,
    },
    forecast: forecast.slice(0, 5).map((item: any, index: number) => {
      const dayWindSpeed = item.wind.speed * 3.6;
      const dayWaveHeight = Math.max(0.3, (dayWindSpeed / 25) * 1.5);
      const dayWavePeriod = Math.max(4, 8 - (dayWindSpeed / 10));
      
      return {
        date: index === 0 ? 'היום' : 
              index === 1 ? 'מחר' : 
              new Date(item.dt * 1000).toLocaleDateString('he-IL', { weekday: 'short' }),
        temp: Math.round(item.main.temp),
        tempMin: Math.round(item.main.temp_min),
        tempMax: Math.round(item.main.temp_max),
        windSpeed: Math.round(dayWindSpeed),
        windDirection: item.wind.deg || 270,
        windGust: Math.round(item.wind.gust || dayWindSpeed * 1.3),
        waveHeight: Number(dayWaveHeight.toFixed(1)),
        wavePeriod: Number(dayWavePeriod.toFixed(1)),
        swellHeight: Number((dayWaveHeight * 0.7).toFixed(1)),
        swellPeriod: Number((dayWavePeriod * 1.2).toFixed(1)),
        description: item.weather[0].description,
        icon: item.weather[0].icon,
        surfCondition: getSurfConditionHebrew(dayWaveHeight, dayWindSpeed, dayWavePeriod),
        surfRating: getSurfRating(dayWaveHeight, dayWindSpeed, dayWavePeriod, item.wind.deg || 270),
        precipitation: item.rain?.['3h'] || 0,
        cloudCover: item.clouds?.all || 30,
      };
    }),
    hourly: forecast.slice(0, 24).map((item: any) => ({
      time: new Date(item.dt * 1000).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }),
      temp: Math.round(item.main.temp),
      windSpeed: Math.round(item.wind.speed * 3.6),
      windDirection: item.wind.deg || 270,
      waveHeight: Number((Math.max(0.3, (item.wind.speed * 3.6 / 25) * 1.5)).toFixed(1)),
      surfRating: getSurfRating(Math.max(0.3, (item.wind.speed * 3.6 / 25) * 1.5), item.wind.speed * 3.6, Math.max(4, 8 - (item.wind.speed * 3.6 / 10)), item.wind.deg || 270),
    })),
  };
};

const getRealisticMockData = (beach: Beach): WeatherData => {
  const now = new Date();
  const month = now.getMonth();
  const hour = now.getHours();
  const isWinter = month >= 11 || month <= 2;
  const isSummer = month >= 5 && month <= 8;
  
  const baseTemp = isWinter ? 16 : isSummer ? 26 : 21;
  const baseWaveHeight = isWinter ? 1.6 : isSummer ? 0.9 : 1.2;
  const baseWindSpeed = isWinter ? 22 : isSummer ? 14 : 18;
  const basePeriod = isWinter ? 7 : 5;
  
  const tempVariation = Math.sin((hour - 6) * Math.PI / 12) * 4;
  const waveVariation = (Math.random() - 0.5) * 0.8;
  const windVariation = (Math.random() - 0.5) * 8;
  
  const currentWaveHeight = Math.max(0.2, baseWaveHeight + waveVariation);
  const currentWindSpeed = Math.max(5, baseWindSpeed + windVariation);
  const currentTemp = Math.round(baseTemp + tempVariation + (Math.random() - 0.5) * 4);
  const currentPeriod = Math.max(3, basePeriod + (Math.random() - 0.5) * 2);
  const windDirection = 250 + Math.floor(Math.random() * 80);

  return {
    location: beach.name,
    coordinates: beach.coordinates,
    current: {
      temp: currentTemp,
      windSpeed: Math.round(currentWindSpeed),
      windDirection,
      windGust: Math.round(currentWindSpeed * 1.3),
      visibility: 8 + Math.floor(Math.random() * 4),
      waveHeight: Number(currentWaveHeight.toFixed(1)),
      wavePeriod: Number(currentPeriod.toFixed(1)),
      swellHeight: Number((currentWaveHeight * 0.75).toFixed(1)),
      swellDirection: windDirection + 20,
      swellPeriod: Number((currentPeriod * 1.2).toFixed(1)),
      description: isWinter ? 'עננים פזורים' : isSummer ? 'שמיים בהירים' : 'חלקית מעונן',
      humidity: 55 + Math.floor(Math.random() * 25),
      pressure: 1008 + Math.floor(Math.random() * 12),
      surfCondition: getSurfConditionHebrew(currentWaveHeight, currentWindSpeed, currentPeriod),
      surfRating: getSurfRating(currentWaveHeight, currentWindSpeed, currentPeriod, windDirection),
      tideHeight: Number((1.2 + Math.sin(Date.now() / 1000000) * 0.8).toFixed(1)),
      tideDirection: getTideDirection(1.2),
      uvIndex: Math.max(1, Math.min(11, Math.round(6 + Math.random() * 4))),
      cloudCover: 20 + Math.floor(Math.random() * 40),
    },
    forecast: Array.from({ length: 5 }, (_, index) => {
      const dayOffset = index * 0.3;
      const dayWaveHeight = Math.max(0.2, baseWaveHeight + (Math.random() - 0.5) * 1.0 + dayOffset);
      const dayWindSpeed = Math.max(5, baseWindSpeed + (Math.random() - 0.5) * 10);
      const dayTemp = Math.round(baseTemp + (Math.random() - 0.5) * 6);
      const dayPeriod = Math.max(3, basePeriod + (Math.random() - 0.5) * 3);
      const dayWindDirection = 250 + Math.floor(Math.random() * 80);
      
      return {
        date: index === 0 ? 'היום' : 
              index === 1 ? 'מחר' : 
              new Date(Date.now() + index * 24 * 60 * 60 * 1000).toLocaleDateString('he-IL', { weekday: 'short' }),
        temp: dayTemp,
        tempMin: dayTemp - 3,
        tempMax: dayTemp + 4,
        windSpeed: Math.round(dayWindSpeed),
        windDirection: dayWindDirection,
        windGust: Math.round(dayWindSpeed * 1.3),
        waveHeight: Number(dayWaveHeight.toFixed(1)),
        wavePeriod: Number(dayPeriod.toFixed(1)),
        swellHeight: Number((dayWaveHeight * 0.75).toFixed(1)),
        swellPeriod: Number((dayPeriod * 1.2).toFixed(1)),
        description: Math.random() > 0.6 ? 'עננים פזורים' : 'שמיים בהירים',
        icon: Math.random() > 0.6 ? '03d' : '01d',
        surfCondition: getSurfConditionHebrew(dayWaveHeight, dayWindSpeed, dayPeriod),
        surfRating: getSurfRating(dayWaveHeight, dayWindSpeed, dayPeriod, dayWindDirection),
        precipitation: Math.random() * 3,
        cloudCover: 20 + Math.floor(Math.random() * 40),
      };
    }),
    hourly: Array.from({ length: 24 }, (_, index) => {
      const hourWaveHeight = Math.max(0.2, baseWaveHeight + (Math.random() - 0.5) * 0.6);
      const hourWindSpeed = Math.max(5, baseWindSpeed + (Math.random() - 0.5) * 6);
      const hourTemp = Math.round(baseTemp + Math.sin((index - 6) * Math.PI / 12) * 3);
      const hourWindDirection = 250 + Math.floor(Math.random() * 80);
      
      return {
        time: `${String(index).padStart(2, '0')}:00`,
        temp: hourTemp,
        windSpeed: Math.round(hourWindSpeed),
        windDirection: hourWindDirection,
        waveHeight: Number(hourWaveHeight.toFixed(1)),
        surfRating: getSurfRating(hourWaveHeight, hourWindSpeed, basePeriod, hourWindDirection),
      };
    }),
  };
};

export const getBeachById = (beachId: string): Beach | undefined => {
  return ISRAELI_BEACHES.find(beach => beach.id === beachId);
};

export const searchBeaches = (query: string): Beach[] => {
  const lowercaseQuery = query.toLowerCase();
  return ISRAELI_BEACHES.filter(beach => 
    beach.name.toLowerCase().includes(lowercaseQuery) ||
    beach.city.toLowerCase().includes(lowercaseQuery) ||
    beach.region.toLowerCase().includes(lowercaseQuery)
  );
};