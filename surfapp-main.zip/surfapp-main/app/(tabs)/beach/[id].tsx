import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Linking,
  Share,
  Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as Location from 'expo-location';
import {
  ArrowLeft,
  MapPin,
  Navigation,
  Share2,
  Camera,
  Users,
  Car,
  Droplets,
  Utensils,
  Waves,
  Wind,
  Thermometer,
  Star,
  Clock,
  TrendingUp,
} from 'lucide-react-native';
import { fetchWeatherData, getBeachById, WeatherData, Beach } from '@/services/weatherApi';

export default function BeachDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const [beach, setBeach] = useState<Beach | null>(null);
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadBeachData();
    }
  }, [id]);

  const loadBeachData = async () => {
    try {
      const beachData = getBeachById(id);
      if (beachData) {
        setBeach(beachData);
        const weather = await fetchWeatherData(id);
        setWeatherData(weather);
      }
    } catch (error) {
      Alert.alert('שגיאה', 'לא ניתן לטעון את נתוני החוף');
    } finally {
      setLoading(false);
    }
  };

  const openInMaps = async () => {
    if (!beach) return;

    const { lat, lon } = beach.coordinates;
    const label = encodeURIComponent(beach.name);
    
    const urls = {
      ios: `maps:0,0?q=${label}@${lat},${lon}`,
      android: `geo:0,0?q=${lat},${lon}(${label})`,
      web: `https://www.google.com/maps/search/?api=1&query=${lat},${lon}`,
    };

    const url = Platform.select(urls) || urls.web;

    try {
      const supported = await Linking.canOpenURL(url);
      if (supported) {
        await Linking.openURL(url);
      } else {
        await Linking.openURL(urls.web);
      }
    } catch (error) {
      Alert.alert('שגיאה', 'לא ניתן לפתוח את המפות');
    }
  };

  const shareBeach = async () => {
    if (!beach) return;

    const message = `בדוק את ${beach.name} ב${beach.city}!\n\n${beach.description}\n\nתנאי גלישה: ${beach.difficulty}\n\nמיקום: https://maps.google.com/?q=${beach.coordinates.lat},${beach.coordinates.lon}`;

    try {
      await Share.share({
        message,
        title: beach.name,
      });
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  const getDirections = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('הרשאה נדרשת', 'נדרשת הרשאה למיקום כדי לקבל הוראות נסיעה');
        return;
      }

      const location = await Location.getCurrentPositionAsync({});
      const { latitude, longitude } = location.coords;
      
      if (!beach) return;
      
      const url = Platform.select({
        ios: `maps:saddr=${latitude},${longitude}&daddr=${beach.coordinates.lat},${beach.coordinates.lon}`,
        android: `google.navigation:q=${beach.coordinates.lat},${beach.coordinates.lon}`,
        default: `https://www.google.com/maps/dir/${latitude},${longitude}/${beach.coordinates.lat},${beach.coordinates.lon}`,
      });

      if (url) {
        await Linking.openURL(url);
      }
    } catch (error) {
      Alert.alert('שגיאה', 'לא ניתן לקבל הוראות נסיעה');
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'מתחילים': return '#10b981';
      case 'בינוני': return '#f59e0b';
      case 'מתקדמים': return '#ef4444';
      case 'מומחים': return '#8b5cf6';
      default: return '#6b7280';
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>טוען נתוני חוף...</Text>
      </View>
    );
  }

  if (!beach) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>חוף לא נמצא</Text>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backButtonText}>חזור</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
            <ArrowLeft size={24} color="#374151" />
          </TouchableOpacity>
          
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.actionButton} onPress={shareBeach}>
              <Share2 size={20} color="#374151" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton} onPress={openInMaps}>
              <MapPin size={20} color="#374151" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Beach Info */}
        <View style={styles.beachInfo}>
          <View style={styles.beachHeader}>
            <View style={styles.beachTitleContainer}>
              <Text style={styles.beachName}>{beach.name}</Text>
              <Text style={styles.beachLocation}>{beach.city}, {beach.region}</Text>
            </View>
            <View style={[styles.difficultyBadge, { backgroundColor: getDifficultyColor(beach.difficulty) }]}>
              <Text style={styles.difficultyText}>{beach.difficulty}</Text>
            </View>
          </View>
          
          <Text style={styles.beachDescription}>{beach.description}</Text>
          
          <Text style={styles.bestConditions}>תנאים מיטביים: {beach.bestConditions}</Text>
        </View>

        {/* Current Conditions */}
        {weatherData && (
          <View style={styles.conditionsCard}>
            <Text style={styles.cardTitle}>תנאים נוכחיים</Text>
            
            <View style={styles.mainConditions}>
              <View style={styles.conditionItem}>
                <Waves size={32} color="#0ea5e9" />
                <Text style={styles.conditionValue}>{weatherData.current.waveHeight}מ'</Text>
                <Text style={styles.conditionLabel}>גובה גלים</Text>
              </View>
              
              <View style={styles.conditionItem}>
                <Wind size={32} color="#10b981" />
                <Text style={styles.conditionValue}>{weatherData.current.windSpeed}</Text>
                <Text style={styles.conditionLabel}>קמ"ש רוח</Text>
              </View>
              
              <View style={styles.conditionItem}>
                <Thermometer size={32} color="#f59e0b" />
                <Text style={styles.conditionValue}>{weatherData.current.temp}°</Text>
                <Text style={styles.conditionLabel}>טמפרטורה</Text>
              </View>
            </View>
            
            <View style={styles.surfRating}>
              <TrendingUp size={20} color="#374151" />
              <Text style={styles.surfRatingText}>דירוג גלישה: {weatherData.current.surfRating}/10</Text>
            </View>
            
            <Text style={styles.surfCondition}>{weatherData.current.surfCondition}</Text>
          </View>
        )}

        {/* Facilities */}
        <View style={styles.facilitiesCard}>
          <Text style={styles.cardTitle}>מתקנים ושירותים</Text>
          
          <View style={styles.facilitiesGrid}>
            <View style={[styles.facilityItem, beach.lifeguard && styles.facilityActive]}>
              <Users size={20} color={beach.lifeguard ? '#10b981' : '#9ca3af'} />
              <Text style={[styles.facilityText, beach.lifeguard && styles.facilityActiveText]}>
                מצילים
              </Text>
            </View>
            
            <View style={[styles.facilityItem, beach.parking && styles.facilityActive]}>
              <Car size={20} color={beach.parking ? '#10b981' : '#9ca3af'} />
              <Text style={[styles.facilityText, beach.parking && styles.facilityActiveText]}>
                חניה
              </Text>
            </View>
            
            <View style={[styles.facilityItem, beach.showers && styles.facilityActive]}>
              <Droplets size={20} color={beach.showers ? '#10b981' : '#9ca3af'} />
              <Text style={[styles.facilityText, beach.showers && styles.facilityActiveText]}>
                מקלחות
              </Text>
            </View>
            
            <View style={[styles.facilityItem, beach.restaurants && styles.facilityActive]}>
              <Utensils size={20} color={beach.restaurants ? '#10b981' : '#9ca3af'} />
              <Text style={[styles.facilityText, beach.restaurants && styles.facilityActiveText]}>
                מסעדות
              </Text>
            </View>
          </View>
        </View>

        {/* Hourly Forecast */}
        {weatherData && (
          <View style={styles.hourlyCard}>
            <Text style={styles.cardTitle}>תחזית שעתית</Text>
            
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={styles.hourlyContainer}>
                {weatherData.hourly.slice(0, 12).map((hour, index) => (
                  <View key={index} style={styles.hourlyItem}>
                    <Text style={styles.hourlyTime}>{hour.time}</Text>
                    <View style={styles.hourlyWave}>
                      <Waves size={16} color="#0ea5e9" />
                      <Text style={styles.hourlyValue}>{hour.waveHeight}מ'</Text>
                    </View>
                    <View style={styles.hourlyWind}>
                      <Wind size={16} color="#10b981" />
                      <Text style={styles.hourlyValue}>{hour.windSpeed}</Text>
                    </View>
                    <View style={styles.hourlyRating}>
                      <Star size={14} color="#f59e0b" fill={hour.surfRating >= 7 ? '#f59e0b' : 'transparent'} />
                      <Text style={styles.hourlyValue}>{hour.surfRating}</Text>
                    </View>
                  </View>
                ))}
              </View>
            </ScrollView>
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.primaryButton} onPress={getDirections}>
            <Navigation size={20} color="#ffffff" />
            <Text style={styles.primaryButtonText}>הוראות נסיעה</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.secondaryButton} onPress={openInMaps}>
            <MapPin size={20} color="#374151" />
            <Text style={styles.secondaryButtonText}>פתח במפות</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    fontSize: 16,
    color: '#374151',
    fontFamily: 'Heebo-Medium',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    padding: 20,
  },
  errorText: {
    fontSize: 18,
    color: '#374151',
    marginBottom: 20,
    fontFamily: 'Heebo-SemiBold',
  },
  scrollContainer: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f3f4f6',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#374151',
    fontSize: 16,
    fontWeight: '600',
    fontFamily: 'Heebo-SemiBold',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f3f4f6',
    justifyContent: 'center',
    alignItems: 'center',
  },
  beachInfo: {
    backgroundColor: '#ffffff',
    padding: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  beachHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  beachTitleContainer: {
    flex: 1,
  },
  beachName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#111827',
    fontFamily: 'Heebo-Bold',
  },
  beachLocation: {
    fontSize: 16,
    color: '#6b7280',
    marginTop: 4,
    fontFamily: 'Heebo-Regular',
  },
  difficultyBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    marginLeft: 16,
  },
  difficultyText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
    fontFamily: 'Heebo-SemiBold',
  },
  beachDescription: {
    fontSize: 16,
    color: '#374151',
    lineHeight: 24,
    marginBottom: 12,
    fontFamily: 'Heebo-Regular',
  },
  bestConditions: {
    fontSize: 14,
    color: '#6b7280',
    fontStyle: 'italic',
    fontFamily: 'Heebo-Regular',
  },
  conditionsCard: {
    backgroundColor: '#ffffff',
    margin: 16,
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 20,
    fontFamily: 'Heebo-SemiBold',
  },
  mainConditions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  conditionItem: {
    alignItems: 'center',
  },
  conditionValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginTop: 8,
    fontFamily: 'Heebo-Bold',
  },
  conditionLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
    fontFamily: 'Heebo-Regular',
  },
  surfRating: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  surfRatingText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginLeft: 8,
    fontFamily: 'Heebo-SemiBold',
  },
  surfCondition: {
    fontSize: 14,
    color: '#6b7280',
    textAlign: 'center',
    fontFamily: 'Heebo-Regular',
  },
  facilitiesCard: {
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  facilitiesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  facilityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    minWidth: '45%',
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  facilityActive: {
    backgroundColor: '#f0f9ff',
    borderColor: '#10b981',
  },
  facilityText: {
    fontSize: 14,
    color: '#9ca3af',
    marginLeft: 8,
    fontFamily: 'Heebo-Regular',
  },
  facilityActiveText: {
    color: '#111827',
    fontWeight: '500',
    fontFamily: 'Heebo-Medium',
  },
  hourlyCard: {
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  hourlyContainer: {
    flexDirection: 'row',
    gap: 16,
  },
  hourlyItem: {
    alignItems: 'center',
    minWidth: 60,
  },
  hourlyTime: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 8,
    fontFamily: 'Heebo-Regular',
  },
  hourlyWave: {
    alignItems: 'center',
    marginBottom: 6,
  },
  hourlyWind: {
    alignItems: 'center',
    marginBottom: 6,
  },
  hourlyRating: {
    alignItems: 'center',
  },
  hourlyValue: {
    fontSize: 11,
    color: '#374151',
    marginTop: 2,
    fontFamily: 'Heebo-Regular',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: 16,
    paddingBottom: 32,
  },
  primaryButton: {
    flex: 1,
    backgroundColor: '#374151',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  primaryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    fontFamily: 'Heebo-SemiBold',
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: '#f3f4f6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  secondaryButtonText: {
    color: '#374151',
    fontSize: 16,
    fontWeight: '600',
    fontFamily: 'Heebo-SemiBold',
  },
});