import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  Alert,
  TouchableOpacity,
  Modal,
  FlatList,
  Linking,
} from 'react-native';
import {
  Waves,
  Wind,
  Eye,
  Thermometer,
  Calendar,
  MapPin,
  ChevronDown,
  Camera,
  Droplets,
  Gauge,
  Navigation,
  Timer,
  TrendingUp,
} from 'lucide-react-native';
import { fetchWeatherData, BEACH_CAMERAS, WeatherData, BeachCamera } from '@/services/weatherApi';

interface Beach {
  id: string;
  name: string;
  city: string;
  region: string;
}

const ISRAELI_BEACHES: Beach[] = [
  // תל אביב
  { id: 'gordon', name: 'חוף גורדון', city: 'תל אביב', region: 'מרכז' },
  { id: 'frishman', name: 'חוף פרישמן', city: 'תל אביב', region: 'מרכז' },
  { id: 'banana', name: 'חוף בננה', city: 'תל אביב', region: 'מרכז' },
  { id: 'hilton', name: 'חוף הילטון', city: 'תל אביב', region: 'מרכז' },
  { id: 'jerusalem', name: 'חוף ירושלים', city: 'תל אביב', region: 'מרכז' },
  { id: 'dolphinarium', name: 'חוף דולפינריום', city: 'תל אביב', region: 'מרכז' },
  { id: 'alma', name: 'חוף אלמה', city: 'תל אביב', region: 'מרכז' },
  { id: 'charles_clore', name: 'חוף צ\'רלס קלור', city: 'תל אביב', region: 'מרכז' },
  
  // הרצליה
  { id: 'herzliya_marina', name: 'מרינה הרצליה', city: 'הרצליה', region: 'מרכז' },
  { id: 'herzliya_pituach', name: 'חוף הרצליה פיתוח', city: 'הרצליה', region: 'מרכז' },
  { id: 'apollonia', name: 'חוף אפולוניה', city: 'הרצליה', region: 'מרכז' },
  
  // נתניה
  { id: 'netanya_main', name: 'חוף נתניה הראשי', city: 'נתניה', region: 'מרכז' },
  { id: 'netanya_north', name: 'חוף נתניה צפון', city: 'נתניה', region: 'מרכז' },
  { id: 'netanya_south', name: 'חוף נתניה דרום', city: 'נתניה', region: 'מרכז' },
  { id: 'poleg', name: 'חוף פולג', city: 'נתניה', region: 'מרכז' },
  
  // חיפה והצפון
  { id: 'haifa_carmel', name: 'חוף כרמל', city: 'חיפה', region: 'צפון' },
  { id: 'haifa_dado', name: 'חוף דדו', city: 'חיפה', region: 'צפון' },
  { id: 'haifa_bat_galim', name: 'חוף בת גלים', city: 'חיפה', region: 'צפון' },
  { id: 'akko', name: 'חוף עכו', city: 'עכו', region: 'צפון' },
  { id: 'nahariya', name: 'חוף נהריה', city: 'נהריה', region: 'צפון' },
  { id: 'rosh_hanikra', name: 'ראש הנקרה', city: 'ראש הנקרה', region: 'צפון' },
  { id: 'achziv', name: 'חוף אכזיב', city: 'אכזיב', region: 'צפון' },
  
  // אשדוד ואשקלון
  { id: 'ashdod_main', name: 'חוף אשדוד הראשי', city: 'אשדוד', region: 'דרום' },
  { id: 'ashdod_north', name: 'חוף אשדוד צפון', city: 'אשדוד', region: 'דרום' },
  { id: 'ashkelon_main', name: 'חוף אשקלון הראשי', city: 'אשקלון', region: 'דרום' },
  { id: 'ashkelon_north', name: 'חוף אשקלון צפון', city: 'אשקלון', region: 'דרום' },
  { id: 'palmachim', name: 'חוף פלמחים', city: 'פלמחים', region: 'דרום' },
  
  // ראשון לציון ובת ים
  { id: 'rishon_main', name: 'חוף ראשון לציון', city: 'ראשון לציון', region: 'מרכז' },
  { id: 'bat_yam', name: 'חוף בת ים', city: 'בת ים', region: 'מרכז' },
  
  // חדרה
  { id: 'hadera', name: 'חוף חדרה', city: 'חדרה', region: 'מרכז' },
  { id: 'caesarea', name: 'חוף קיסריה', city: 'קיסריה', region: 'מרכז' },
  
  // זכרון יעקב ובנימינה
  { id: 'jisr_az_zarqa', name: 'חוף ג\'סר א-זרקא', city: 'ג\'סר א-זרקא', region: 'מרכז' },
  { id: 'dor', name: 'חוף דור', city: 'דור', region: 'מרכז' },
  
  // חופים נוספים
  { id: 'mikhmoret', name: 'חוף מכמורת', city: 'מכמורת', region: 'מרכז' },
  { id: 'beit_yanai', name: 'חוף בית ינאי', city: 'בית ינאי', region: 'מרכז' },
  { id: 'ga_ash', name: 'חוף גע\'ש', city: 'גע\'ש', region: 'מרכז' },
];

export default function ForecastScreen() {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedBeach, setSelectedBeach] = useState<Beach>(ISRAELI_BEACHES[0]);
  const [beachModalVisible, setBeachModalVisible] = useState(false);
  const [camerasModalVisible, setCamerasModalVisible] = useState(false);

  const fetchData = async () => {
    try {
      const data = await fetchWeatherData(selectedBeach.id);
      setWeatherData(data);
    } catch (error) {
      Alert.alert('שגיאה', 'לא ניתן לטעון את נתוני התחזית');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedBeach]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchData();
  };

  const openCamera = (camera: BeachCamera) => {
    if (camera.isActive) {
      Linking.openURL(camera.url);
    } else {
      Alert.alert('מצלמה לא זמינה', 'המצלמה אינה פעילה כרגע');
    }
  };

  const getWaveConditionColor = (height: number) => {
    if (height < 0.8) return '#ef4444';
    if (height < 1.3) return '#f59e0b';
    if (height < 2.0) return '#10b981';
    return '#3b82f6';
  };

  const getWindDirectionText = (degrees: number) => {
    const directions = ['צפון', 'צפון-מזרח', 'מזרח', 'דרום-מזרח', 'דרום', 'דרום-מערב', 'מערב', 'צפון-מערב'];
    const index = Math.round(degrees / 45) % 8;
    return directions[index];
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#374151" />
        <Text style={styles.loadingText}>טוען תחזית...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollContainer}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        showsVerticalScrollIndicator={false}>
        
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <Text style={styles.headerTitle}>תחזית גלישה</Text>
            <TouchableOpacity 
              style={styles.cameraButton}
              onPress={() => setCamerasModalVisible(true)}
            >
              <Camera size={22} color="#374151" />
            </TouchableOpacity>
          </View>
          
          <TouchableOpacity 
            style={styles.beachSelector}
            onPress={() => setBeachModalVisible(true)}
          >
            <View style={styles.beachSelectorContent}>
              <ChevronDown size={18} color="#6b7280" />
              <Text style={styles.beachSelectorText}>{selectedBeach.name}</Text>
              <MapPin size={18} color="#374151" />
            </View>
          </TouchableOpacity>
          
          <Text style={styles.dateText}>{new Date().toLocaleDateString('he-IL', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          })}</Text>
        </View>

        {/* Current Conditions */}
        <View style={styles.currentCard}>
          <Text style={styles.cardTitle}>תנאים נוכחיים</Text>
          
          <View style={styles.mainConditions}>
            <View style={styles.waveInfo}>
              <Waves size={44} color="#374151" />
              <Text style={styles.waveHeight}>{weatherData?.current.waveHeight.toFixed(1)}מ'</Text>
              <Text style={[
                styles.waveCondition,
                { color: getWaveConditionColor(weatherData?.current.waveHeight || 0) }
              ]}>
                {weatherData?.current.surfCondition}
              </Text>
            </View>
            
            <View style={styles.tempInfo}>
              <Thermometer size={36} color="#374151" />
              <Text style={styles.temperature}>{weatherData?.current.temp}°</Text>
              <Text style={styles.tempLabel}>צלזיוס</Text>
            </View>
          </View>

          <View style={styles.conditionsGrid}>
            <View style={styles.conditionItem}>
              <Wind size={18} color="#6b7280" />
              <Text style={styles.conditionValue}>{weatherData?.current.windSpeed}</Text>
              <Text style={styles.conditionLabel}>קמ"ש רוח</Text>
            </View>
            
            <View style={styles.conditionItem}>
              <Navigation size={18} color="#6b7280" />
              <Text style={styles.conditionValue}>{getWindDirectionText(weatherData?.current.windDirection || 0)}</Text>
              <Text style={styles.conditionLabel}>כיוון רוח</Text>
            </View>
            
            <View style={styles.conditionItem}>
              <Timer size={18} color="#6b7280" />
              <Text style={styles.conditionValue}>{weatherData?.current.wavePeriod.toFixed(1)}</Text>
              <Text style={styles.conditionLabel}>שניות תקופה</Text>
            </View>
            
            <View style={styles.conditionItem}>
              <Eye size={18} color="#6b7280" />
              <Text style={styles.conditionValue}>{weatherData?.current.visibility}</Text>
              <Text style={styles.conditionLabel}>ק"מ ראות</Text>
            </View>
            
            <View style={styles.conditionItem}>
              <Droplets size={18} color="#6b7280" />
              <Text style={styles.conditionValue}>{weatherData?.current.humidity}%</Text>
              <Text style={styles.conditionLabel}>לחות</Text>
            </View>
            
            <View style={styles.conditionItem}>
              <TrendingUp size={18} color="#6b7280" />
              <Text style={styles.conditionValue}>{weatherData?.current.surfRating}/10</Text>
              <Text style={styles.conditionLabel}>דירוג גלישה</Text>
            </View>
          </View>

          <View style={styles.descriptionContainer}>
            <Text style={styles.description}>{weatherData?.current.description}</Text>
            <Text style={styles.pressure}>לחץ אוויר: {weatherData?.current.pressure} hPa</Text>
          </View>
        </View>

        {/* 5-Day Forecast */}
        <View style={styles.forecastCard}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>תחזית 5 ימים</Text>
            <Calendar size={22} color="#374151" />
          </View>

          {weatherData?.forecast.map((day, index) => (
            <View key={index} style={[
              styles.forecastItem,
              index === weatherData.forecast.length - 1 && styles.lastForecastItem
            ]}>
              <View style={styles.forecastDay}>
                <Text style={styles.dayText}>{day.date}</Text>
                <Text style={styles.dayTemp}>{day.temp}°</Text>
              </View>
              
              <View style={styles.forecastConditions}>
                <View style={styles.forecastMetric}>
                  <Waves size={16} color="#374151" />
                  <Text style={styles.forecastMetricText}>{day.waveHeight.toFixed(1)}מ'</Text>
                </View>
                
                <View style={styles.forecastMetric}>
                  <Wind size={16} color="#6b7280" />
                  <Text style={styles.forecastMetricText}>{day.windSpeed} קמ"ש</Text>
                </View>
                
                <View style={styles.forecastMetric}>
                  <Timer size={16} color="#6b7280" />
                  <Text style={styles.forecastMetricText}>{day.wavePeriod.toFixed(1)}ש'</Text>
                </View>
                
                <Text style={[
                  styles.forecastDescription,
                  { color: getWaveConditionColor(day.waveHeight) }
                ]}>
                  {day.surfCondition}
                </Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>

      {/* Beach Selection Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={beachModalVisible}
        onRequestClose={() => setBeachModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>בחר חוף</Text>
            <FlatList
              data={ISRAELI_BEACHES}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.beachItem,
                    selectedBeach.id === item.id && styles.selectedBeachItem
                  ]}
                  onPress={() => {
                    setSelectedBeach(item);
                    setBeachModalVisible(false);
                  }}
                >
                  <View style={styles.beachItemContent}>
                    <Text style={styles.beachItemName}>{item.name}</Text>
                    <Text style={styles.beachItemLocation}>{item.city}, {item.region}</Text>
                  </View>
                  {selectedBeach.id === item.id && (
                    <View style={styles.selectedIndicator} />
                  )}
                </TouchableOpacity>
              )}
              showsVerticalScrollIndicator={false}
            />
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setBeachModalVisible(false)}
            >
              <Text style={styles.closeButtonText}>סגור</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Beach Cameras Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={camerasModalVisible}
        onRequestClose={() => setCamerasModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>מצלמות חוף</Text>
            <FlatList
              data={BEACH_CAMERAS}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.cameraItem,
                    !item.isActive && styles.inactiveCameraItem
                  ]}
                  onPress={() => openCamera(item)}
                >
                  <View style={styles.cameraItemContent}>
                    <Camera size={22} color={item.isActive ? '#374151' : '#9ca3af'} />
                    <View style={styles.cameraInfo}>
                      <Text style={[
                        styles.cameraName,
                        !item.isActive && styles.inactiveCameraText
                      ]}>
                        {item.name}
                      </Text>
                      <Text style={[
                        styles.cameraLocation,
                        !item.isActive && styles.inactiveCameraText
                      ]}>
                        {item.location}
                      </Text>
                    </View>
                    <View style={[
                      styles.statusIndicator,
                      { backgroundColor: item.isActive ? '#10b981' : '#ef4444' }
                    ]} />
                  </View>
                </TouchableOpacity>
              )}
              showsVerticalScrollIndicator={false}
            />
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setCamerasModalVisible(false)}
            >
              <Text style={styles.closeButtonText}>סגור</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#374151',
    fontWeight: '500',
    fontFamily: 'Heebo-Medium',
  },
  scrollContainer: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: '700',
    color: '#111827',
    fontFamily: 'Heebo-Bold',
  },
  cameraButton: {
    padding: 10,
    borderRadius: 10,
    backgroundColor: '#f3f4f6',
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  beachSelector: {
    backgroundColor: '#f9fafb',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  beachSelectorContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  beachSelectorText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    flex: 1,
    textAlign: 'center',
    fontFamily: 'Heebo-SemiBold',
  },
  dateText: {
    fontSize: 14,
    color: '#6b7280',
    textAlign: 'center',
    fontFamily: 'Heebo-Regular',
  },
  currentCard: {
    marginHorizontal: 16,
    marginTop: 16,
    marginBottom: 16,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 20,
    textAlign: 'right',
    fontFamily: 'Heebo-SemiBold',
  },
  mainConditions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginBottom: 24,
    paddingVertical: 16,
  },
  waveInfo: {
    alignItems: 'center',
    flex: 1,
  },
  waveHeight: {
    fontSize: 28,
    fontWeight: '700',
    color: '#111827',
    marginTop: 8,
    fontFamily: 'Heebo-Bold',
  },
  waveCondition: {
    fontSize: 12,
    fontWeight: '600',
    marginTop: 4,
    textAlign: 'center',
    fontFamily: 'Heebo-SemiBold',
  },
  tempInfo: {
    alignItems: 'center',
    flex: 1,
  },
  temperature: {
    fontSize: 28,
    fontWeight: '700',
    color: '#111827',
    marginTop: 8,
    fontFamily: 'Heebo-Bold',
  },
  tempLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
    fontFamily: 'Heebo-Regular',
  },
  conditionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  conditionItem: {
    alignItems: 'center',
    width: '31%',
    backgroundColor: '#f9fafb',
    padding: 14,
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  conditionValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginTop: 6,
    fontFamily: 'Heebo-SemiBold',
  },
  conditionLabel: {
    fontSize: 11,
    color: '#6b7280',
    marginTop: 4,
    textAlign: 'center',
    fontFamily: 'Heebo-Regular',
  },
  descriptionContainer: {
    alignItems: 'center',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#f3f4f6',
  },
  description: {
    fontSize: 15,
    color: '#374151',
    textAlign: 'center',
    fontWeight: '500',
    marginBottom: 4,
    fontFamily: 'Heebo-Medium',
  },
  pressure: {
    fontSize: 13,
    color: '#6b7280',
    textAlign: 'center',
    fontFamily: 'Heebo-Regular',
  },
  forecastCard: {
    marginHorizontal: 16,
    marginBottom: 32,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  forecastItem: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  lastForecastItem: {
    borderBottomWidth: 0,
  },
  forecastDay: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  dayText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#111827',
    fontFamily: 'Heebo-SemiBold',
  },
  dayTemp: {
    fontSize: 17,
    fontWeight: '700',
    color: '#111827',
    fontFamily: 'Heebo-Bold',
  },
  forecastConditions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  forecastMetric: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  forecastMetricText: {
    marginLeft: 4,
    fontSize: 13,
    fontWeight: '500',
    color: '#374151',
    fontFamily: 'Heebo-Medium',
  },
  forecastDescription: {
    fontSize: 12,
    fontWeight: '600',
    fontFamily: 'Heebo-SemiBold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 24,
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 20,
    textAlign: 'center',
    fontFamily: 'Heebo-Bold',
  },
  beachItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 8,
    backgroundColor: '#f9fafb',
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  selectedBeachItem: {
    backgroundColor: '#f0f9ff',
    borderWidth: 1,
    borderColor: '#374151',
  },
  beachItemContent: {
    flex: 1,
  },
  beachItemName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#111827',
    textAlign: 'right',
    fontFamily: 'Heebo-SemiBold',
  },
  beachItemLocation: {
    fontSize: 13,
    color: '#6b7280',
    marginTop: 2,
    textAlign: 'right',
    fontFamily: 'Heebo-Regular',
  },
  selectedIndicator: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#374151',
  },
  cameraItem: {
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 8,
    backgroundColor: '#f9fafb',
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  inactiveCameraItem: {
    backgroundColor: '#f3f4f6',
  },
  cameraItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cameraInfo: {
    flex: 1,
    marginLeft: 12,
  },
  cameraName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#111827',
    textAlign: 'right',
    fontFamily: 'Heebo-SemiBold',
  },
  cameraLocation: {
    fontSize: 13,
    color: '#6b7280',
    marginTop: 2,
    textAlign: 'right',
    fontFamily: 'Heebo-Regular',
  },
  inactiveCameraText: {
    color: '#9ca3af',
  },
  statusIndicator: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  closeButton: {
    backgroundColor: '#374151',
    paddingVertical: 16,
    borderRadius: 12,
    marginTop: 16,
    alignItems: 'center',
  },
  closeButtonText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '600',
    fontFamily: 'Heebo-SemiBold',
  },
});