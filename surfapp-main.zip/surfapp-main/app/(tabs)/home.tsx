import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Image,
  Alert,
  RefreshControl,
  Dimensions,
} from 'react-native';
import {
  MapPin,
  TrendingUp,
  Users,
  Calendar,
  Waves,
  Wind,
  Thermometer,
  Star,
  ChevronLeft,
  User,
  LogOut,
} from 'lucide-react-native';
import { AuthService, User } from '@/services/authService';
import { ISRAELI_BEACHES, Beach } from '@/services/weatherApi';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [featuredBeaches, setFeaturedBeaches] = useState<Beach[]>([]);

  useEffect(() => {
    loadUserData();
    loadFeaturedBeaches();
  }, []);

  const loadUserData = async () => {
    try {
      const currentUser = await AuthService.getCurrentUser();
      setUser(currentUser);
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadFeaturedBeaches = () => {
    // בחירת חופים מובילים
    const featured = ISRAELI_BEACHES.filter(beach => 
      ['gordon', 'hilton', 'herzliya_marina', 'netanya_main', 'haifa_carmel', 'ashdod_main'].includes(beach.id)
    );
    setFeaturedBeaches(featured);
  };

  const handleSignIn = async () => {
    try {
      const signedInUser = await AuthService.signInWithGoogle();
      if (signedInUser) {
        setUser(signedInUser);
        Alert.alert('ברוך הבא!', `שלום ${signedInUser.name}`);
      }
    } catch (error) {
      Alert.alert('שגיאה', 'לא ניתן להתחבר');
    }
  };

  const handleSignOut = async () => {
    Alert.alert(
      'התנתקות',
      'האם אתה בטוח שברצונך להתנתק?',
      [
        { text: 'ביטול', style: 'cancel' },
        {
          text: 'התנתק',
          style: 'destructive',
          onPress: async () => {
            await AuthService.signOut();
            setUser(null);
          },
        },
      ]
    );
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadUserData();
    setRefreshing(false);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'מתחילים': return '#10b981';
      case 'בינוני': return '#f59e0b';
      case 'מתקדמים': return '#ef4444';
      case 'מומחים': return '#8b5cf6';
      default: return '#6b7280';
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'בוקר טוב';
    if (hour < 18) return 'צהריים טובים';
    return 'ערב טוב';
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>טוען...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollContainer}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <View style={styles.headerLeft}>
              <Text style={styles.greeting}>
                {getGreeting()}{user ? `, ${user.name.split(' ')[0]}` : ''}
              </Text>
              <Text style={styles.subtitle}>מוכן לגלוש היום?</Text>
            </View>
            
            <View style={styles.headerRight}>
              {user ? (
                <TouchableOpacity style={styles.profileButton} onPress={handleSignOut}>
                  {user.photo ? (
                    <Image source={{ uri: user.photo }} style={styles.profileImage} />
                  ) : (
                    <View style={styles.profilePlaceholder}>
                      <User size={24} color="#374151" />
                    </View>
                  )}
                </TouchableOpacity>
              ) : (
                <TouchableOpacity style={styles.signInButton} onPress={handleSignIn}>
                  <Text style={styles.signInButtonText}>התחבר</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statsCard}>
            <View style={styles.statItem}>
              <Waves size={24} color="#0ea5e9" />
              <Text style={styles.statValue}>1.2מ'</Text>
              <Text style={styles.statLabel}>גובה גלים ממוצע</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Wind size={24} color="#10b981" />
              <Text style={styles.statValue}>18 קמ"ש</Text>
              <Text style={styles.statLabel}>רוח ממוצעת</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Thermometer size={24} color="#f59e0b" />
              <Text style={styles.statValue}>24°</Text>
              <Text style={styles.statLabel}>טמפרטורה</Text>
            </View>
          </View>
        </View>

        {/* Featured Beaches */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>חופים מומלצים</Text>
            <TouchableOpacity style={styles.seeAllButton}>
              <Text style={styles.seeAllText}>ראה הכל</Text>
              <ChevronLeft size={16} color="#6b7280" />
            </TouchableOpacity>
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.beachesScrollContainer}
          >
            {featuredBeaches.map((beach) => (
              <TouchableOpacity key={beach.id} style={styles.beachCard}>
                <View style={styles.beachImageContainer}>
                  <View style={styles.beachImagePlaceholder}>
                    <MapPin size={32} color="#ffffff" />
                  </View>
                  <View style={[styles.difficultyBadge, { backgroundColor: getDifficultyColor(beach.difficulty) }]}>
                    <Text style={styles.difficultyText}>{beach.difficulty}</Text>
                  </View>
                </View>
                
                <View style={styles.beachInfo}>
                  <Text style={styles.beachName}>{beach.name}</Text>
                  <Text style={styles.beachLocation}>{beach.city}</Text>
                  
                  <View style={styles.beachFeatures}>
                    {beach.lifeguard && (
                      <View style={styles.feature}>
                        <Users size={12} color="#10b981" />
                        <Text style={styles.featureText}>מצילים</Text>
                      </View>
                    )}
                    {beach.parking && (
                      <View style={styles.feature}>
                        <MapPin size={12} color="#6b7280" />
                        <Text style={styles.featureText}>חניה</Text>
                      </View>
                    )}
                  </View>
                  
                  <View style={styles.beachRating}>
                    <Star size={14} color="#f59e0b" fill="#f59e0b" />
                    <Text style={styles.ratingText}>4.{Math.floor(Math.random() * 9) + 1}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Today's Conditions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>תנאים היום</Text>
          
          <View style={styles.conditionsCard}>
            <View style={styles.conditionRow}>
              <View style={styles.conditionItem}>
                <Waves size={20} color="#0ea5e9" />
                <Text style={styles.conditionLabel}>גלים</Text>
                <Text style={styles.conditionValue}>0.8-1.5מ'</Text>
              </View>
              <View style={styles.conditionItem}>
                <Wind size={20} color="#10b981" />
                <Text style={styles.conditionLabel}>רוח</Text>
                <Text style={styles.conditionValue}>15-22 קמ"ש</Text>
              </View>
            </View>
            
            <View style={styles.conditionRow}>
              <View style={styles.conditionItem}>
                <TrendingUp size={20} color="#f59e0b" />
                <Text style={styles.conditionLabel}>דירוג</Text>
                <Text style={styles.conditionValue}>7/10</Text>
              </View>
              <View style={styles.conditionItem}>
                <Calendar size={20} color="#8b5cf6" />
                <Text style={styles.conditionLabel}>מגמה</Text>
                <Text style={styles.conditionValue}>משתפר</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        {user && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>פעולות מהירות</Text>
            
            <View style={styles.actionsGrid}>
              <TouchableOpacity style={styles.actionCard}>
                <Calendar size={24} color="#374151" />
                <Text style={styles.actionText}>הוסף סשן</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.actionCard}>
                <MapPin size={24} color="#374151" />
                <Text style={styles.actionText}>מצא חוף</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.actionCard}>
                <TrendingUp size={24} color="#374151" />
                <Text style={styles.actionText}>סטטיסטיקות</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.actionCard}>
                <Users size={24} color="#374151" />
                <Text style={styles.actionText}>חברים</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    fontSize: 16,
    color: '#374151',
    fontFamily: 'Heebo-Medium',
  },
  scrollContainer: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerLeft: {
    flex: 1,
  },
  greeting: {
    fontSize: 24,
    fontWeight: '700',
    color: '#111827',
    fontFamily: 'Heebo-Bold',
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    marginTop: 4,
    fontFamily: 'Heebo-Regular',
  },
  headerRight: {
    marginLeft: 16,
  },
  profileButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    overflow: 'hidden',
  },
  profileImage: {
    width: 48,
    height: 48,
    borderRadius: 24,
  },
  profilePlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f3f4f6',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  signInButton: {
    backgroundColor: '#374151',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  signInButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
    fontFamily: 'Heebo-SemiBold',
  },
  statsContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  statsCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
    marginTop: 8,
    fontFamily: 'Heebo-Bold',
  },
  statLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
    textAlign: 'center',
    fontFamily: 'Heebo-Regular',
  },
  statDivider: {
    width: 1,
    height: 40,
    backgroundColor: '#f3f4f6',
    marginHorizontal: 16,
  },
  section: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#111827',
    fontFamily: 'Heebo-SemiBold',
  },
  seeAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  seeAllText: {
    fontSize: 14,
    color: '#6b7280',
    marginRight: 4,
    fontFamily: 'Heebo-Regular',
  },
  beachesScrollContainer: {
    paddingRight: 20,
  },
  beachCard: {
    width: width * 0.7,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    marginRight: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  beachImageContainer: {
    height: 120,
    position: 'relative',
  },
  beachImagePlaceholder: {
    flex: 1,
    backgroundColor: '#374151',
    justifyContent: 'center',
    alignItems: 'center',
  },
  difficultyBadge: {
    position: 'absolute',
    top: 12,
    right: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  difficultyText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
    fontFamily: 'Heebo-SemiBold',
  },
  beachInfo: {
    padding: 16,
  },
  beachName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    fontFamily: 'Heebo-SemiBold',
  },
  beachLocation: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 2,
    fontFamily: 'Heebo-Regular',
  },
  beachFeatures: {
    flexDirection: 'row',
    marginTop: 8,
    gap: 12,
  },
  feature: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  featureText: {
    fontSize: 12,
    color: '#6b7280',
    marginLeft: 4,
    fontFamily: 'Heebo-Regular',
  },
  beachRating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginLeft: 4,
    fontFamily: 'Heebo-SemiBold',
  },
  conditionsCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  conditionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  conditionItem: {
    alignItems: 'center',
    flex: 1,
  },
  conditionLabel: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 8,
    fontFamily: 'Heebo-Regular',
  },
  conditionValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginTop: 4,
    fontFamily: 'Heebo-SemiBold',
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionCard: {
    width: (width - 64) / 2,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  actionText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginTop: 8,
    fontFamily: 'Heebo-SemiBold',
  },
});