import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  Platform,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  Plus,
  Calendar,
  Clock,
  Waves,
  Star,
  MapPin,
  Edit3,
  Trash2,
} from 'lucide-react-native';

interface SurfSession {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  duration: number;
  location: string;
  waveHeight: number;
  rating: number;
  notes: string;
}

export default function DiaryScreen() {
  const [sessions, setSessions] = useState<SurfSession[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingSession, setEditingSession] = useState<SurfSession | null>(null);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    startTime: '',
    endTime: '',
    location: '',
    waveHeight: '',
    rating: 5,
    notes: '',
  });

  const STORAGE_KEY = 'surfSessions';

  useEffect(() => {
    loadSessions();
  }, []);

  const loadSessions = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsedSessions = JSON.parse(stored);
        setSessions(parsedSessions.sort((a: SurfSession, b: SurfSession) => 
          new Date(b.date).getTime() - new Date(a.date).getTime()
        ));
      }
    } catch (error) {
      console.error('Error loading sessions:', error);
    }
  };

  const saveSessions = async (newSessions: SurfSession[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newSessions));
      setSessions(newSessions);
    } catch (error) {
      Alert.alert('שגיאה', 'לא ניתן לשמור את הנתונים');
    }
  };

  const calculateDuration = (start: string, end: string) => {
    if (!start || !end) return 0;
    const startTime = new Date(`2000-01-01T${start}`);
    const endTime = new Date(`2000-01-01T${end}`);
    const diff = endTime.getTime() - startTime.getTime();
    return Math.max(0, diff / (1000 * 60)); // minutes
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours} שעות ${mins} דקות`;
    }
    return `${mins} דקות`;
  };

  const openAddModal = () => {
    setEditingSession(null);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      startTime: '',
      endTime: '',
      location: '',
      waveHeight: '',
      rating: 5,
      notes: '',
    });
    setModalVisible(true);
  };

  const openEditModal = (session: SurfSession) => {
    setEditingSession(session);
    setFormData({
      date: session.date,
      startTime: session.startTime,
      endTime: session.endTime,
      location: session.location,
      waveHeight: session.waveHeight.toString(),
      rating: session.rating,
      notes: session.notes,
    });
    setModalVisible(true);
  };

  const saveSession = () => {
    if (!formData.startTime || !formData.endTime || !formData.location || !formData.waveHeight) {
      Alert.alert('שגיאה', 'אנא מלא את כל השדות הנדרשים');
      return;
    }

    const duration = calculateDuration(formData.startTime, formData.endTime);
    if (duration <= 0) {
      Alert.alert('שגיאה', 'שעת הסיום חייבת להיות אחרי שעת ההתחלה');
      return;
    }

    const session: SurfSession = {
      id: editingSession?.id || Date.now().toString(),
      date: formData.date,
      startTime: formData.startTime,
      endTime: formData.endTime,
      duration,
      location: formData.location,
      waveHeight: parseFloat(formData.waveHeight),
      rating: formData.rating,
      notes: formData.notes,
    };

    let newSessions;
    if (editingSession) {
      newSessions = sessions.map(s => s.id === editingSession.id ? session : s);
    } else {
      newSessions = [session, ...sessions];
    }

    newSessions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    saveSessions(newSessions);
    setModalVisible(false);
  };

  const deleteSession = (sessionId: string) => {
    Alert.alert(
      'מחיקת סשן',
      'האם אתה בטוח שברצונך למחוק את הסשן הזה?',
      [
        { text: 'ביטול', style: 'cancel' },
        { 
          text: 'מחק', 
          style: 'destructive',
          onPress: () => {
            const newSessions = sessions.filter(s => s.id !== sessionId);
            saveSessions(newSessions);
          }
        }
      ]
    );
  };

  const renderStars = (rating: number, onPress?: (rating: number) => void) => {
    return (
      <View style={styles.starsContainer}>
        {[1, 2, 3, 4, 5].map(star => (
          <TouchableOpacity
            key={star}
            onPress={() => onPress?.(star)}
            disabled={!onPress}
          >
            <Star
              size={24}
              color={star <= rating ? '#f59e0b' : '#d1d5db'}
              fill={star <= rating ? '#f59e0b' : 'transparent'}
            />
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  const getTotalStats = () => {
    const totalSessions = sessions.length;
    const totalTime = sessions.reduce((sum, session) => sum + session.duration, 0);
    const avgRating = sessions.length > 0 
      ? sessions.reduce((sum, session) => sum + session.rating, 0) / sessions.length 
      : 0;

    return { totalSessions, totalTime, avgRating };
  };

  const stats = getTotalStats();

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>יומן הגלישה שלי</Text>
          <TouchableOpacity style={styles.addButton} onPress={openAddModal}>
            <Plus size={24} color="#2563eb" />
          </TouchableOpacity>
        </View>

        {/* Stats */}
        <View style={styles.statsCard}>
          <Text style={styles.cardTitle}>סטטיסטיקות</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{stats.totalSessions}</Text>
              <Text style={styles.statLabel}>סשנים</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{formatDuration(stats.totalTime)}</Text>
              <Text style={styles.statLabel}>זמן כולל</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{stats.avgRating.toFixed(1)}</Text>
              <Text style={styles.statLabel}>דירוג ממוצע</Text>
            </View>
          </View>
        </View>

        {/* Sessions List */}
        <View style={styles.sessionsCard}>
          <Text style={styles.cardTitle}>סשנים אחרונים</Text>
          
          {sessions.length === 0 ? (
            <View style={styles.emptyState}>
              <Waves size={48} color="#94a3b8" />
              <Text style={styles.emptyText}>עדיין לא הוספת סשנים</Text>
              <TouchableOpacity style={styles.emptyButton} onPress={openAddModal}>
                <Text style={styles.emptyButtonText}>הוסף סשן ראשון</Text>
              </TouchableOpacity>
            </View>
          ) : (
            sessions.map((session) => (
              <View key={session.id} style={styles.sessionItem}>
                <View style={styles.sessionHeader}>
                  <View style={styles.sessionDate}>
                    <Calendar size={20} color="#0ea5e9" />
                    <Text style={styles.sessionDateText}>
                      {new Date(session.date).toLocaleDateString('he-IL')}
                    </Text>
                  </View>
                  <View style={styles.sessionActions}>
                    <TouchableOpacity onPress={() => openEditModal(session)}>
                      <Edit3 size={20} color="#6b7280" />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => deleteSession(session.id)}>
                      <Trash2 size={20} color="#ef4444" />
                    </TouchableOpacity>
                  </View>
                </View>

                <View style={styles.sessionLocation}>
                  <MapPin size={16} color="#6b7280" />
                  <Text style={styles.sessionLocationText}>{session.location}</Text>
                </View>

                <View style={styles.sessionDetails}>
                  <View style={styles.sessionTime}>
                    <Clock size={16} color="#6b7280" />
                    <Text style={styles.sessionTimeText}>
                      {session.startTime} - {session.endTime} ({formatDuration(session.duration)})
                    </Text>
                  </View>
                  
                  <View style={styles.sessionWave}>
                    <Waves size={16} color="#0ea5e9" />
                    <Text style={styles.sessionWaveText}>{session.waveHeight}מ'</Text>
                  </View>
                </View>

                <View style={styles.sessionRating}>
                  {renderStars(session.rating)}
                </View>

                {session.notes && (
                  <Text style={styles.sessionNotes}>{session.notes}</Text>
                )}
              </View>
            ))
          )}
        </View>
      </ScrollView>

      {/* Add/Edit Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {editingSession ? 'עריכת סשן' : 'הוספת סשן חדש'}
            </Text>

            <View style={styles.formRow}>
              <Text style={styles.label}>תאריך:</Text>
              <TextInput
                style={styles.input}
                value={formData.date}
                onChangeText={(text) => setFormData({ ...formData, date: text })}
                placeholder="YYYY-MM-DD"
              />
            </View>

            <View style={styles.formRow}>
              <View style={styles.timeInputs}>
                <View style={styles.timeInput}>
                  <Text style={styles.label}>שעת התחלה:</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.startTime}
                    onChangeText={(text) => setFormData({ ...formData, startTime: text })}
                    placeholder="HH:MM"
                  />
                </View>
                <View style={styles.timeInput}>
                  <Text style={styles.label}>שעת סיום:</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.endTime}
                    onChangeText={(text) => setFormData({ ...formData, endTime: text })}
                    placeholder="HH:MM"
                  />
                </View>
              </View>
            </View>

            <View style={styles.formRow}>
              <Text style={styles.label}>מיקום:</Text>
              <TextInput
                style={styles.input}
                value={formData.location}
                onChangeText={(text) => setFormData({ ...formData, location: text })}
                placeholder="למשל: חוף גורדון, תל אביב"
              />
            </View>

            <View style={styles.formRow}>
              <Text style={styles.label}>גובה גלים (מטר):</Text>
              <TextInput
                style={styles.input}
                value={formData.waveHeight}
                onChangeText={(text) => setFormData({ ...formData, waveHeight: text })}
                placeholder="1.5"
                keyboardType="numeric"
              />
            </View>

            <View style={styles.formRow}>
              <Text style={styles.label}>דירוג הסשן:</Text>
              {renderStars(formData.rating, (rating) => 
                setFormData({ ...formData, rating })
              )}
            </View>

            <View style={styles.formRow}>
              <Text style={styles.label}>הערות:</Text>
              <TextInput
                style={[styles.input, styles.notesInput]}
                value={formData.notes}
                onChangeText={(text) => setFormData({ ...formData, notes: text })}
                placeholder="איך היה הסשן? מה למדת?"
                multiline
                numberOfLines={3}
              />
            </View>

            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setModalVisible(false)}>
                <Text style={styles.cancelButtonText}>ביטול</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={saveSession}>
                <Text style={styles.saveButtonText}>שמור</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  scrollContainer: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 60,
    paddingHorizontal: 24,
    paddingBottom: 24,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: '#111827',
    fontFamily: 'Heebo-Bold',
  },
  addButton: {
    backgroundColor: '#f3f4f6',
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#374151',
  },
  statsCard: {
    marginHorizontal: 16,
    marginBottom: 16,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 20,
    textAlign: 'right',
    fontFamily: 'Heebo-SemiBold',
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#111827',
    fontFamily: 'Heebo-Bold',
  },
  statLabel: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 4,
    fontFamily: 'Heebo-Regular',
  },
  sessionsCard: {
    marginHorizontal: 16,
    marginBottom: 32,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 16,
    color: '#6b7280',
    marginTop: 16,
    marginBottom: 24,
  },
  emptyButton: {
    backgroundColor: '#374151',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  emptyButtonText: {
    color: '#ffffff',
    fontWeight: '600',
    fontFamily: 'Heebo-SemiBold',
  },
  sessionItem: {
    backgroundColor: '#f9fafb',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  sessionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sessionDate: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sessionDateText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginLeft: 8,
    fontFamily: 'Heebo-SemiBold',
  },
  sessionActions: {
    flexDirection: 'row',
    gap: 12,
  },
  sessionLocation: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  sessionLocationText: {
    fontSize: 14,
    color: '#6b7280',
    marginLeft: 4,
  },
  sessionDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sessionTime: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sessionTimeText: {
    fontSize: 14,
    color: '#6b7280',
    marginLeft: 4,
  },
  sessionWave: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sessionWaveText: {
    fontSize: 14,
    color: '#111827',
    fontWeight: '600',
    marginLeft: 4,
    fontFamily: 'Heebo-SemiBold',
  },
  sessionRating: {
    marginBottom: 12,
  },
  starsContainer: {
    flexDirection: 'row',
    gap: 4,
  },
  sessionNotes: {
    fontSize: 14,
    color: '#374151',
    fontStyle: 'italic',
    backgroundColor: '#f3f4f6',
    padding: 12,
    borderRadius: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    maxWidth: 400,
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 24,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 24,
    textAlign: 'center',
    fontFamily: 'Heebo-Bold',
  },
  formRow: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
    textAlign: 'right',
    fontFamily: 'Heebo-SemiBold',
  },
  input: {
    backgroundColor: '#f9fafb',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    textAlign: 'right',
    fontFamily: 'Heebo-Regular',
  },
  timeInputs: {
    flexDirection: 'row',
    gap: 12,
  },
  timeInput: {
    flex: 1,
  },
  notesInput: {
    height: 80,
    textAlignVertical: 'top',
  },
  modalActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#f1f5f9',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
    fontFamily: 'Heebo-SemiBold',
  },
  saveButton: {
    flex: 1,
    backgroundColor: '#374151',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    fontFamily: 'Heebo-SemiBold',
  },
});